#include <reproc/reproc.h>

#include "error.h"
#include "handle.h"
#include "macro.h"
#include "pipe.h"
#include "process.h"
#include "redirect.h"

#include <assert.h>
#include <stdlib.h>

struct reproc_t {
  handle handle;
  struct stdio stdio;
  int status;
  reproc_stop_actions stop;
  int timeout;
};

enum { STATUS_NOT_STARTED = -2, STATUS_IN_PROGRESS = -1 };

const int REPROC_SIGKILL = UINT8_MAX + 9;
const int REPROC_SIGTERM = UINT8_MAX + 15;

const int REPROC_INFINITE = -1;

static int redirect(handle *parent,
                    handle *child,
                    REPROC_STREAM stream,
                    REPROC_REDIRECT type)
{
  assert(parent);
  assert(child);

  int r = -1;

  switch (type) {

    case REPROC_REDIRECT_PIPE:
      r = redirect_pipe(parent, child, (REDIRECT_STREAM) stream);
      break;

    case REPROC_REDIRECT_INHERIT:;
      r = redirect_inherit(parent, child, (REDIRECT_STREAM) stream);
      // Discard if the corresponding parent stream is closed.
      r = r == REPROC_EPIPE
              ? redirect_discard(parent, child, (REDIRECT_STREAM) stream)
              : r;
      break;

    case REPROC_REDIRECT_DISCARD:
      r = redirect_discard(parent, child, (REDIRECT_STREAM) stream);
      break;

    default:
      r = REPROC_EINVAL;
      break;
  }

  return r;
}

reproc_t *reproc_new(void)
{
  reproc_t *process = malloc(sizeof(reproc_t));
  if (process == NULL) {
    return NULL;
  }

  *process = (reproc_t){ .handle = HANDLE_INVALID,
                         .stdio = { .in = HANDLE_INVALID,
                                    .out = HANDLE_INVALID,
                                    .err = HANDLE_INVALID },
                         .status = STATUS_NOT_STARTED,
                         .timeout = REPROC_INFINITE };

  return process;
}

int reproc_start(reproc_t *process,
                 const char *const *argv,
                 reproc_options options)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(process->status == STATUS_NOT_STARTED, REPROC_EINVAL);
  assert_return(argv, REPROC_EINVAL);
  assert_return(argv[0], REPROC_EINVAL);

  struct stdio child = { HANDLE_INVALID, HANDLE_INVALID, HANDLE_INVALID };

  int r = -1;

  r = redirect(&process->stdio.in, &child.in, REPROC_STREAM_IN,
               options.redirect.in);
  if (r < 0) {
    goto finish;
  }

  r = redirect(&process->stdio.out, &child.out, REPROC_STREAM_OUT,
               options.redirect.out);
  if (r < 0) {
    goto finish;
  }

  r = redirect(&process->stdio.err, &child.err, REPROC_STREAM_ERR,
               options.redirect.err);
  if (r < 0) {
    goto finish;
  }

  struct process_options process_options = {
    .environment = options.environment,
    .working_directory = options.working_directory,
    .redirect = child
  };

  r = process_start(&process->handle, argv, process_options);
  if (r < 0) {
    goto finish;
  }

  process->timeout = options.timeout == 0 ? REPROC_INFINITE : options.timeout;
  process->stop = options.stop;

  bool is_noop = process->stop.first.action == REPROC_STOP_NOOP &&
                 process->stop.second.action == REPROC_STOP_NOOP &&
                 process->stop.third.action == REPROC_STOP_NOOP;

  if (is_noop) {
    process->stop.first.action = REPROC_STOP_WAIT;
    process->stop.first.timeout = REPROC_INFINITE;
  }

finish:
  // Either an error has ocurred or the child pipe endpoints have been copied to
  // the stdin/stdout/stderr streams of the child process. Either way, they can
  // be safely closed in the parent process.
  handle_destroy(child.in);
  handle_destroy(child.out);
  handle_destroy(child.err);

  if (r < 0) {
    process->handle = process_destroy(process->handle);
    process->stdio.in = handle_destroy(process->stdio.in);
    process->stdio.out = handle_destroy(process->stdio.out);
    process->stdio.err = handle_destroy(process->stdio.err);
  } else {
    process->status = STATUS_IN_PROGRESS;
  }

  return r;
}

int reproc_read(reproc_t *process,
                REPROC_STREAM *stream,
                uint8_t *buffer,
                size_t size)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(buffer, REPROC_EINVAL);

  handle ready = HANDLE_INVALID;
  int r = -1;

  while (true) {
    // Get the first pipe that will have data available to be read.
    r = pipe_wait(process->stdio.out, process->stdio.err, &ready,
                  process->timeout);
    if (r < 0) {
      return r;
    }

    r = pipe_read(ready, buffer, size);
    if (r >= 0) {
      break;
    }

    if (r != REPROC_EPIPE) {
      return r;
    }

    // If the pipe was closed, destroy its handle and try waiting again.

    if (ready == process->stdio.out) {
      process->stdio.out = handle_destroy(process->stdio.out);
    } else {
      process->stdio.err = handle_destroy(process->stdio.err);
    }
  }

  if (stream) {
    *stream = ready == process->stdio.out ? REPROC_STREAM_OUT
                                          : REPROC_STREAM_ERR;
  }

  return r; // bytes read
}

int reproc_write(reproc_t *process, const uint8_t *buffer, size_t size)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(buffer, REPROC_EINVAL);

  if (process->stdio.in == HANDLE_INVALID) {
    return REPROC_EPIPE;
  }

  int r = -1;

  do {
    r = pipe_write(process->stdio.in, buffer, size, process->timeout);

    if (r == REPROC_EPIPE) {
      process->stdio.in = handle_destroy(process->stdio.in);
    }

    if (r < 0) {
      break;
    }

    size_t bytes_written = (size_t) r;

    buffer += bytes_written;
    size -= bytes_written;
  } while (size != 0);

  return r < 0 ? r : 0;
}

int reproc_close(reproc_t *process, REPROC_STREAM stream)
{
  assert_return(process, REPROC_EINVAL);

  switch (stream) {
    case REPROC_STREAM_IN:
      process->stdio.in = handle_destroy(process->stdio.in);
      break;
    case REPROC_STREAM_OUT:
      process->stdio.out = handle_destroy(process->stdio.out);
      break;
    case REPROC_STREAM_ERR:
      process->stdio.err = handle_destroy(process->stdio.err);
      break;
    default:
      return REPROC_EINVAL;
  }

  return 0;
}

int reproc_wait(reproc_t *process, int timeout)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(process->status != STATUS_NOT_STARTED, REPROC_EINVAL);

  int r = -1;

  if (process->status >= 0) {
    return process->status;
  }

  r = process_wait(process->handle, timeout);
  if (r < 0) {
    return r;
  }

  return process->status = r;
}

int reproc_terminate(reproc_t *process)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(process->status != STATUS_NOT_STARTED, REPROC_EINVAL);

  if (process->status >= 0) {
    return 0;
  }

  return process_terminate(process->handle);
}

int reproc_kill(reproc_t *process)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(process->status != STATUS_NOT_STARTED, REPROC_EINVAL);

  if (process->status >= 0) {
    return 0;
  }

  return process_kill(process->handle);
}

int reproc_stop(reproc_t *process, reproc_stop_actions stop)
{
  assert_return(process, REPROC_EINVAL);
  assert_return(process->status != STATUS_NOT_STARTED, REPROC_EINVAL);

  reproc_stop_action actions[3] = { stop.first, stop.second, stop.third };
  int r = -1;

  for (size_t i = 0; i < ARRAY_SIZE(actions); i++) {
    switch (actions[i].action) {
      case REPROC_STOP_NOOP:
        continue;
      case REPROC_STOP_WAIT:
        r = 0;
        break;
      case REPROC_STOP_TERMINATE:
        r = reproc_terminate(process);
        break;
      case REPROC_STOP_KILL:
        r = reproc_kill(process);
        break;
      default:
        return REPROC_EINVAL;
    }

    // Stop if `reproc_terminate` or `reproc_kill` fail.
    if (r < 0) {
      break;
    }

    r = reproc_wait(process, actions[i].timeout);
    if (r != REPROC_ETIMEDOUT) {
      break;
    }
  }

  return r;
}

reproc_t *reproc_destroy(reproc_t *process)
{
  assert_return(process, NULL);

  if (process->status == STATUS_IN_PROGRESS) {
    reproc_stop(process, process->stop);
  }

  process->handle = process_destroy(process->handle);
  process->stdio.in = handle_destroy(process->stdio.in);
  process->stdio.out = handle_destroy(process->stdio.out);
  process->stdio.err = handle_destroy(process->stdio.err);

  free(process);
  return NULL;
}

const char *reproc_strerror(int error)
{
  return error_string(error);
}
